﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DESK_MES
{
    public partial class frmDefectList : FormStyle_3
    {
        public frmDefectList()
        {
            InitializeComponent();
            label1.Text = "불량 이력";
        }
    }
}
